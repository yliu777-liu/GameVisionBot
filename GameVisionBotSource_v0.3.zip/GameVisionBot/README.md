# GameVisionBot

一个安卓视觉自动化原型：截取手机画面，交给视觉 API 分析，再按返回的归一化坐标执行安全受限的点击或滑动。

## 已实现

- MediaProjection 屏幕截取
- 本地颜色聚类、棋盘识别和交换搜索（消消乐优先使用）
- 连续两帧一致才执行，避免动画过程中误滑
- 本地无法识别时才调用视觉 API，并可用 API 返回值自动校准棋盘
- OpenAI-compatible `/chat/completions` 视觉接口
- 通用 JSON 图片接口
- `MATCH3` 消消乐自动滑动/点击
- `CLAW_AUTO` 抓娃娃自动移动和下爪
- 无障碍手势执行
- 目标游戏包名白名单
- 置信度低于 0.65 时拒绝执行
- 禁止视觉模型点击充值、付款、购买确认或广告区域
- GitHub Actions 自动构建 APK

## 安装与使用

1. 在仓库的 **Actions → Build Android APK** 构建页面下载 `GameVisionBot-debug-apk`。
2. 解压后在安卓手机安装 `GameVisionBot-debug.apk`。
3. 填入 API 地址、API Key、模型名称和目标游戏包名。消消乐默认按 9×9 棋盘运行，可按界面说明调整棋盘参数。
4. 开启 GameVisionBot 无障碍服务。
5. 点击“授权截屏并开始”，同意系统截屏提示，再切换到游戏。

API Key 不会写入源码或 GitHub，只保存在 App 的本机设置中，并发送到用户填写的接口地址。

## 通用接口格式

请求：

```json
{
  "model": "your-model",
  "mode": "MATCH3",
  "prompt": "...",
  "image_mime": "image/jpeg",
  "image_base64": "..."
}
```

响应：

```json
{
  "action": "swipe",
  "x1": 410,
  "y1": 620,
  "x2": 520,
  "y2": 620,
  "confidence": 0.91,
  "reason": "交换后形成四连"
}
```

坐标范围为 0～1000，按整张屏幕归一化。

## 注意

这是调试版原型，请只在你有权操作的 App 和游戏中使用，并遵守目标服务条款。不同厂商系统可能会额外限制后台截屏或无障碍服务；如果被系统停止，需要关闭电池优化并重新授权。
