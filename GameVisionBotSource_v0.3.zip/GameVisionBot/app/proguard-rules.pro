# No shrinking rules are needed for the debug prototype.
