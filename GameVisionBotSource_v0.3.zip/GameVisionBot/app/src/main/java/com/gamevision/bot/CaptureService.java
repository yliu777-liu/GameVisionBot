package com.gamevision.bot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class CaptureService extends Service {
    static final String ACTION_START = "com.gamevision.bot.START";
    static final String ACTION_STOP = "com.gamevision.bot.STOP";
    static final String EXTRA_RESULT_CODE = "result_code";
    static final String EXTRA_RESULT_DATA = "result_data";

    private static final String CHANNEL_ID = "game_vision_capture";
    private static final int NOTIFICATION_ID = 42;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean requestInProgress = new AtomicBoolean(false);
    private long lastCaptureAt;
    private String lastBoardSignature = "";
    private String lastActedSignature = "";
    private int stableFrames;
    private int localMisses;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        captureThread = new HandlerThread("game-vision-capture");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_NOT_STICKY;
        }
        if (ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction()) || mediaProjection != null) {
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, notification("正在准备截屏…"));
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        if (resultData == null) {
            updateStatus("截屏授权无效，请重新开始");
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager manager =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mediaProjection = manager.getMediaProjection(resultCode, resultData);
        if (mediaProjection == null) {
            updateStatus("无法启动截屏");
            stopSelf();
            return START_NOT_STICKY;
        }
        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf();
            }
        }, captureHandler);
        startVirtualDisplay();
        updateStatus("运行中：等待游戏画面");
        return START_NOT_STICKY;
    }

    private void startVirtualDisplay() {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "GameVisionBotCapture",
                width,
                height,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                captureHandler);
        imageReader.setOnImageAvailableListener(this::onImageAvailable, captureHandler);
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = reader.acquireLatestImage();
        if (image == null) {
            return;
        }
        SharedPreferences prefs = getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE);
        long interval = Math.max(350, prefs.getLong(AppConfig.KEY_INTERVAL, 650));
        long now = System.currentTimeMillis();
        if (requestInProgress.get() || now - lastCaptureAt < interval) {
            image.close();
            return;
        }
        lastCaptureAt = now;

        Bitmap bitmap;
        try {
            bitmap = imageToBitmap(image);
        } finally {
            image.close();
        }
        String mode = prefs.getString(AppConfig.KEY_MODE, "MATCH3");
        if ("MATCH3".equals(mode)) {
            Match3Solver.Solution solution = Match3Solver.solve(bitmap, prefs);
            if (solution != null) {
                localMisses = 0;
                if (solution.signature.equals(lastBoardSignature)) {
                    stableFrames++;
                } else {
                    lastBoardSignature = solution.signature;
                    stableFrames = 1;
                }
                if (!solution.signature.equals(lastActedSignature) && stableFrames >= 2) {
                    boolean dispatched = GameAccessibilityService.perform(
                            "swipe", solution.x1, solution.y1, solution.x2, solution.y2);
                    if (dispatched) {
                        lastActedSignature = solution.signature;
                    }
                    stableFrames = 0;
                    updateStatus((dispatched ? "本地已滑动" : "未滑动："
                            + GameAccessibilityService.lastFailure())
                            + " · 得分 " + solution.score
                            + " · 可信度 " + String.format("%.2f", solution.confidence));
                }
                bitmap.recycle();
                return;
            }
            localMisses++;
            if (localMisses < 3) {
                bitmap.recycle();
                return;
            }
            localMisses = 0;
        }

        byte[] jpeg = bitmapToJpeg(bitmap);
        bitmap.recycle();
        if (jpeg.length == 0 || !requestInProgress.compareAndSet(false, true)) {
            return;
        }
        networkExecutor.execute(() -> {
            try {
                analyze(jpeg);
            } catch (Exception e) {
                updateStatus("识别失败：" + readableMessage(e));
            } finally {
                requestInProgress.set(false);
            }
        });
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * image.getWidth();
        int bitmapWidth = image.getWidth() + rowPadding / pixelStride;
        Bitmap padded = Bitmap.createBitmap(bitmapWidth, image.getHeight(), Bitmap.Config.ARGB_8888);
        padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, image.getWidth(), image.getHeight());
        padded.recycle();
        return cropped;
    }

    private byte[] bitmapToJpeg(Bitmap bitmap) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 68, output);
        return output.toByteArray();
    }

    private void analyze(byte[] jpeg) throws Exception {
        SharedPreferences prefs = getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE);
        String endpoint = prefs.getString(AppConfig.KEY_ENDPOINT, "").trim();
        String apiKey = prefs.getString(AppConfig.KEY_API_KEY, "").trim();
        String model = prefs.getString(AppConfig.KEY_MODEL, "deepseek-flash").trim();
        String mode = prefs.getString(AppConfig.KEY_MODE, "MATCH3");
        if (endpoint.isEmpty()) {
            throw new IllegalArgumentException("API 地址为空");
        }

        String base64 = Base64.encodeToString(jpeg, Base64.NO_WRAP);
        boolean openAiCompatible = endpoint.contains("/chat/completions");
        JSONObject request = openAiCompatible
                ? buildOpenAiRequest(model, mode, base64)
                : buildGenericRequest(model, mode, base64);
        String response = postJson(endpoint, apiKey, request.toString());
        JSONObject action = parseAction(response, openAiCompatible);
        saveBoardCalibration(action.optJSONObject("board"));

        String actionName = action.optString("action", "wait").toLowerCase();
        double confidence = action.optDouble("confidence", 0);
        String reason = action.optString("reason", "无说明");
        if (confidence < 0.65) {
            updateStatus("未执行（置信度 " + String.format("%.2f", confidence) + "）：" + reason);
            return;
        }

        boolean dispatched = GameAccessibilityService.perform(
                actionName,
                action.optInt("x1", 0),
                action.optInt("y1", 0),
                action.optInt("x2", action.optInt("x1", 0)),
                action.optInt("y2", action.optInt("y1", 0)));
        updateStatus((dispatched ? "已执行 " : "未执行："
                + GameAccessibilityService.lastFailure() + " · ")
                + actionName + " · " + reason);
    }

    private JSONObject buildGenericRequest(String model, String mode, String base64)
            throws JSONException {
        return new JSONObject()
                .put("model", model)
                .put("mode", mode)
                .put("prompt", prompt(mode))
                .put("image_mime", "image/jpeg")
                .put("image_base64", base64);
    }

    private JSONObject buildOpenAiRequest(String model, String mode, String base64)
            throws JSONException {
        JSONObject imageUrl = new JSONObject()
                .put("url", "data:image/jpeg;base64," + base64)
                .put("detail", "low");
        JSONArray content = new JSONArray()
                .put(new JSONObject().put("type", "text").put("text", prompt(mode)))
                .put(new JSONObject().put("type", "image_url").put("image_url", imageUrl));
        JSONArray messages = new JSONArray()
                .put(new JSONObject().put("role", "user").put("content", content));
        return new JSONObject()
                .put("model", model)
                .put("messages", messages)
                .put("temperature", 0)
                .put("max_tokens", 300);
    }

    private String prompt(String mode) {
        String schema = "只返回一个 JSON 对象，不要 Markdown："
                + "{\"action\":\"swipe|tap|wait\",\"x1\":0到1000,\"y1\":0到1000,"
                + "\"x2\":0到1000,\"y2\":0到1000,\"confidence\":0到1,\"reason\":\"简短中文说明\"}。"
                + "坐标以整张截图左上角为(0,0)、右下角为(1000,1000)。";
        if ("CLAW_AUTO".equals(mode)) {
            return "观察线上抓娃娃画面，判断爪子、目标娃娃和游戏控制按钮的位置。"
                    + "可以返回 tap 或 swipe 来自动移动并在对准后点击下爪按钮；不确定时必须 wait。"
                    + "绝对禁止点击充值、付款、购买确认、广告、返回或退出等非游戏控制区域。" + schema;
        }
        return "识别消消乐棋盘，选择一组相邻方块交换，以形成尽量多的消除。"
                + "同时在 JSON 中加入 board 对象：{\"left\":0到1000,\"top\":0到1000,"
                + "\"right\":0到1000,\"bottom\":0到1000,\"rows\":行数,\"columns\":列数,"
                + "\"tile_types\":图案种类数}，边界必须覆盖棋盘格中心区域。"
                + "如果看不清就返回 wait，绝不要猜测。" + schema;
    }

    private void saveBoardCalibration(JSONObject board) {
        if (board == null) {
            return;
        }
        int columns = board.optInt("columns", 0);
        int rows = board.optInt("rows", 0);
        int left = board.optInt("left", -1);
        int top = board.optInt("top", -1);
        int right = board.optInt("right", -1);
        int bottom = board.optInt("bottom", -1);
        int tileTypes = board.optInt("tile_types", 6);
        if (columns < 3 || columns > 12 || rows < 3 || rows > 12
                || left < 0 || top < 0 || right > 1000 || bottom > 1000
                || right <= left || bottom <= top || tileTypes < 3 || tileTypes > 10) {
            return;
        }
        String value = columns + "," + rows + "," + left + "," + top + ","
                + right + "," + bottom + "," + tileTypes;
        getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE)
                .edit().putString(AppConfig.KEY_BOARD_SPEC, value).apply();
    }

    private String postJson(String endpoint, String apiKey, String body) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        try {
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(60000);
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            if (!apiKey.isEmpty()) {
                connection.setRequestProperty("Authorization", "Bearer " + apiKey);
            }
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream();
            String response = readAll(stream);
            if (status < 200 || status >= 300) {
                throw new IllegalStateException("API " + status + "：" + trim(response, 180));
            }
            return response;
        } finally {
            connection.disconnect();
        }
    }

    private JSONObject parseAction(String response, boolean openAiCompatible) throws JSONException {
        JSONObject outer = new JSONObject(response);
        if (!openAiCompatible || outer.has("action")) {
            return outer;
        }
        JSONArray choices = outer.optJSONArray("choices");
        if (choices == null || choices.length() == 0) {
            throw new JSONException("API 响应没有 choices");
        }
        String content = choices.getJSONObject(0)
                .getJSONObject("message")
                .optString("content", "");
        return new JSONObject(extractJson(content));
    }

    private String extractJson(String text) throws JSONException {
        int start = text.indexOf('{');
        int end = text.lastIndexOf('}');
        if (start < 0 || end <= start) {
            throw new JSONException("模型没有返回 JSON");
        }
        return text.substring(start, end + 1);
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) {
            return "";
        }
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
        }
        return result.toString();
    }

    private String readableMessage(Exception error) {
        String message = error.getMessage();
        return message == null || message.isEmpty() ? error.getClass().getSimpleName() : trim(message, 180);
    }

    private String trim(String value, int max) {
        return value.length() <= max ? value : value.substring(0, max) + "…";
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "画面识别", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("显示 GameVisionBot 的运行状态");
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private Notification notification(String text) {
        Intent openApp = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, openApp, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("GameVisionBot")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    private void updateStatus(String text) {
        getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE)
                .edit().putString(AppConfig.KEY_STATUS, text).apply();
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, notification(text));
    }

    @Override
    public void onDestroy() {
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
        networkExecutor.shutdownNow();
        if (captureThread != null) {
            captureThread.quitSafely();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
