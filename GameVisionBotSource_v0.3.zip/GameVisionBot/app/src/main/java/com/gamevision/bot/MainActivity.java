package com.gamevision.bot;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 1001;
    private static final int REQUEST_NOTIFICATIONS = 1002;

    private EditText endpointInput;
    private EditText apiKeyInput;
    private EditText modelInput;
    private EditText packageInput;
    private EditText intervalInput;
    private EditText boardSpecInput;
    private Spinner modeSpinner;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE);
        setContentView(buildContent());
        loadSettings();

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private View buildContent() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("GameVisionBot");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(15, 23, 42));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("截取手机画面，让视觉 API 给出下一步；支持消消乐自动滑动和抓娃娃自动移动、下爪。\n");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.DKGRAY);
        root.addView(subtitle);

        endpointInput = addInput(root, "API 地址", "https://api.openai.com/v1/chat/completions", false);
        apiKeyInput = addInput(root, "API Key", "sk-...", true);
        modelInput = addInput(root, "模型名称", "gpt-4.1-mini", false);
        packageInput = addInput(root, "允许自动操作的游戏包名（必须填写）", "例如 com.example.game", false);
        intervalInput = addInput(root, "识别间隔（毫秒，最低 350）", "650", false);
        intervalInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        boardSpecInput = addInput(root, "消消乐棋盘参数：列,行,左,上,右,下,图案数", "9,9,30,180,970,950,6", false);

        TextView boardHelp = new TextView(this);
        boardHelp.setText("坐标按整屏 0～1000 计算。默认值适合常见 9×9 棋盘；首次识别失败时，视觉 API 会尝试自动校准。");
        boardHelp.setTextSize(12);
        boardHelp.setTextColor(Color.GRAY);
        root.addView(boardHelp, matchWrap());

        TextView modeLabel = label("运行模式");
        root.addView(modeLabel);
        modeSpinner = new Spinner(this);
        String[] modes = {"MATCH3 - 消消乐自动操作", "CLAW_AUTO - 抓娃娃自动操作"};
        modeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, modes));
        root.addView(modeSpinner, matchWrap());

        Button save = button("保存设置");
        save.setOnClickListener(v -> {
            saveSettings();
            Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
        });
        root.addView(save, buttonParams());

        Button accessibility = button("1. 开启无障碍服务");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility, buttonParams());

        Button start = button("2. 授权截屏并开始");
        start.setOnClickListener(v -> startCapture());
        root.addView(start, buttonParams());

        Button stop = button("停止运行");
        stop.setOnClickListener(v -> {
            Intent intent = new Intent(this, CaptureService.class).setAction(CaptureService.ACTION_STOP);
            startService(intent);
            Toast.makeText(this, "已发送停止指令", Toast.LENGTH_SHORT).show();
        });
        root.addView(stop, buttonParams());

        TextView safety = new TextView(this);
        safety.setText("安全限制：只有 API 置信度达到 0.65 且当前前台应用与包名完全一致时，才会执行动作。抓娃娃模式可自动移动和下爪，但禁止点击充值、付款、广告或购买确认。API Key 只保存在本机，并发送到你填写的 API 地址。");
        safety.setTextSize(13);
        safety.setTextColor(Color.GRAY);
        LinearLayout.LayoutParams safetyParams = matchWrap();
        safetyParams.topMargin = dp(18);
        root.addView(safety, safetyParams);
        return scroll;
    }

    private EditText addInput(LinearLayout root, String title, String hint, boolean password) {
        root.addView(label(title));
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        if (password) {
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        root.addView(input, matchWrap());
        return input;
    }

    private TextView label(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(14);
        label.setTextColor(Color.rgb(30, 41, 59));
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(12);
        label.setLayoutParams(params);
        return label;
    }

    private Button button(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(12);
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void loadSettings() {
        endpointInput.setText(preferences.getString(AppConfig.KEY_ENDPOINT,
                "https://api.openai.com/v1/chat/completions"));
        apiKeyInput.setText(preferences.getString(AppConfig.KEY_API_KEY, ""));
        modelInput.setText(preferences.getString(AppConfig.KEY_MODEL, "gpt-4.1-mini"));
        packageInput.setText(preferences.getString(AppConfig.KEY_PACKAGE, ""));
        intervalInput.setText(String.valueOf(preferences.getLong(AppConfig.KEY_INTERVAL, 650)));
        boardSpecInput.setText(preferences.getString(AppConfig.KEY_BOARD_SPEC,
                "9,9,30,180,970,950,6"));
        modeSpinner.setSelection("CLAW_AUTO".equals(
                preferences.getString(AppConfig.KEY_MODE, "MATCH3")) ? 1 : 0);
    }

    private void saveSettings() {
        long interval = 650;
        try {
            interval = Math.max(350, Long.parseLong(intervalInput.getText().toString().trim()));
        } catch (NumberFormatException ignored) {
        }
        preferences.edit()
                .putString(AppConfig.KEY_ENDPOINT, endpointInput.getText().toString().trim())
                .putString(AppConfig.KEY_API_KEY, apiKeyInput.getText().toString().trim())
                .putString(AppConfig.KEY_MODEL, modelInput.getText().toString().trim())
                .putString(AppConfig.KEY_PACKAGE, packageInput.getText().toString().trim())
                .putLong(AppConfig.KEY_INTERVAL, interval)
                .putString(AppConfig.KEY_BOARD_SPEC, boardSpecInput.getText().toString().trim())
                .putString(AppConfig.KEY_MODE, modeSpinner.getSelectedItemPosition() == 1
                        ? "CLAW_AUTO" : "MATCH3")
                .apply();
    }

    private void startCapture() {
        saveSettings();
        if (packageInput.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "请先填写游戏包名", Toast.LENGTH_LONG).show();
            return;
        }
        MediaProjectionManager manager =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE || resultCode != RESULT_OK || data == null) {
            return;
        }
        Intent service = new Intent(this, CaptureService.class)
                .setAction(CaptureService.ACTION_START)
                .putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_RESULT_DATA, data);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(service);
        } else {
            startService(service);
        }
        Toast.makeText(this, "已开始，请切换到目标游戏", Toast.LENGTH_LONG).show();
    }
}
