package com.gamevision.bot;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 1001;
    private static final int REQUEST_NOTIFICATIONS = 1002;
    private static final String DEFAULT_ENDPOINT =
            "https://api.deepseek.com/chat/completions";
    private static final String DEFAULT_MODEL = "deepseek-flash";
    private static final String DEFAULT_BOARD_SPEC = "8,10,75,255,905,740,6";
    private static final String OLD_BOARD_SPEC = "9,9,30,180,970,950,6";
    private static final long GAME_TEST_DELAY_MILLIS = 5000;

    private EditText endpointInput;
    private EditText apiKeyInput;
    private EditText modelInput;
    private EditText packageInput;
    private EditText intervalInput;
    private EditText boardSpecInput;
    private Spinner modeSpinner;
    private TextView statusView;
    private SharedPreferences preferences;
    private final ExecutorService apiTestExecutor = Executors.newSingleThreadExecutor();
    private final Handler statusHandler = new Handler(Looper.getMainLooper());
    private final Runnable statusRefresh = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            statusHandler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE);
        setContentView(buildContent());
        loadSettings();

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private View buildContent() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("GameVisionBot");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(15, 23, 42));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("截取手机画面；支持消消乐自动滑动，以及本地高速追踪移动爪子、对齐后自动点击抓取。\n");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.DKGRAY);
        root.addView(subtitle);

        endpointInput = addInput(root, "API 地址", DEFAULT_ENDPOINT, false);
        apiKeyInput = addInput(root, "API Key", "sk-...", true);
        modelInput = addInput(root, "模型名称", DEFAULT_MODEL, false);

        Button deepSeekPreset = button("使用 DeepSeek 默认配置");
        deepSeekPreset.setOnClickListener(v -> {
            endpointInput.setText(DEFAULT_ENDPOINT);
            modelInput.setText(DEFAULT_MODEL);
            saveSettings();
            Toast.makeText(this, "已填入 DeepSeek 图片识别配置", Toast.LENGTH_SHORT).show();
        });
        root.addView(deepSeekPreset, buttonParams());

        packageInput = addInput(root, "允许自动操作的游戏包名（必须填写）", "例如 com.example.game", false);
        intervalInput = addInput(root, "消消乐识别间隔（毫秒，最低 350）", "650", false);
        intervalInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        boardSpecInput = addInput(root, "消消乐棋盘参数：列,行,左,上,右,下,图案数",
                DEFAULT_BOARD_SPEC, false);

        TextView boardHelp = new TextView(this);
        boardHelp.setText("坐标按整屏 0～1000 计算。默认值已按你截图中的 8列×10行水果棋盘校准；首次识别失败时，视觉 API 会尝试自动校准。");
        boardHelp.setTextSize(12);
        boardHelp.setTextColor(Color.GRAY);
        root.addView(boardHelp, matchWrap());

        TextView modeLabel = label("运行模式");
        root.addView(modeLabel);
        modeSpinner = new Spinner(this);
        String[] modes = {"MATCH3 - 消消乐自动操作", "CLAW_AUTO - 对齐后自动点击抓取"};
        modeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, modes));
        root.addView(modeSpinner, matchWrap());

        Button save = button("保存设置");
        save.setOnClickListener(v -> {
            saveSettings();
            Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
        });
        root.addView(save, buttonParams());

        Button apiTest = button("测试 DeepSeek API（含图片识别）");
        apiTest.setOnClickListener(v -> testApi(apiTest));
        root.addView(apiTest, buttonParams());

        Button accessibility = button("1. 开启无障碍服务");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility, buttonParams());

        Button controlTest = button("基础测试：滑动本页面");
        controlTest.setOnClickListener(v -> {
            Toast.makeText(this, "即将在本页面执行一次测试滑动", Toast.LENGTH_SHORT).show();
            statusHandler.postDelayed(() -> {
                boolean accepted = GameAccessibilityService.performSelfTest();
                if (!accepted) {
                    Toast.makeText(this, GameAccessibilityService.lastFailure(),
                            Toast.LENGTH_LONG).show();
                }
                refreshStatus();
            }, 700);
        });
        root.addView(controlTest, buttonParams());

        Button clawTapTest = button("抓娃娃点击测试（5秒后点击抓取）");
        clawTapTest.setOnClickListener(v -> scheduleGameControlTest(
                clawTapTest, "抓娃娃点击测试", "tap",
                500, 791, 500, 791));
        root.addView(clawTapTest, buttonParams());

        Button match3SwipeTest = button("消消乐滑动测试（5秒后滑动一格）");
        match3SwipeTest.setOnClickListener(v -> scheduleGameControlTest(
                match3SwipeTest, "消消乐滑动测试", "swipe",
                450, 500, 550, 500));
        root.addView(match3SwipeTest, buttonParams());

        Button start = button("2. 授权截屏并开始");
        start.setOnClickListener(v -> startCapture());
        root.addView(start, buttonParams());

        Button stop = button("停止运行");
        stop.setOnClickListener(v -> {
            Intent intent = new Intent(this, CaptureService.class).setAction(CaptureService.ACTION_STOP);
            startService(intent);
            Toast.makeText(this, "已发送停止指令", Toast.LENGTH_SHORT).show();
        });
        root.addView(stop, buttonParams());

        statusView = new TextView(this);
        statusView.setTextSize(13);
        statusView.setTextColor(Color.rgb(180, 35, 35));
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = dp(16);
        root.addView(statusView, statusParams);

        TextView safety = new TextView(this);
        safety.setText("测试按钮使用方法：点击后在5秒内切回对应小游戏。抓娃娃测试会点击截图中原“开始游戏/抓取”的橙色按钮位置；消消乐测试会在棋盘中央横向滑动一个相邻格。当前前台应用必须与填写的包名完全一致。禁止点击充值、付款、广告或购买确认。API Key 只保存在本机。");
        safety.setTextSize(13);
        safety.setTextColor(Color.GRAY);
        LinearLayout.LayoutParams safetyParams = matchWrap();
        safetyParams.topMargin = dp(18);
        root.addView(safety, safetyParams);
        return scroll;
    }

    @Override
    protected void onResume() {
        super.onResume();
        statusHandler.removeCallbacks(statusRefresh);
        statusHandler.post(statusRefresh);
    }

    @Override
    protected void onPause() {
        statusHandler.removeCallbacks(statusRefresh);
        super.onPause();
    }

    private void refreshStatus() {
        if (statusView == null) {
            return;
        }
        String lastStatus = preferences.getString(
                AppConfig.KEY_STATUS, "尚未开始运行");
        String accessibility = GameAccessibilityService.isConnected()
                ? "已连接" : "未连接";
        String currentPackage = GameAccessibilityService.currentPackage();
        statusView.setText("运行诊断\n无障碍：" + accessibility
                + "\n当前检测包名：" + (currentPackage.isEmpty() ? "未知" : currentPackage)
                + "\n最近状态：" + lastStatus);
    }

    private EditText addInput(LinearLayout root, String title, String hint, boolean password) {
        root.addView(label(title));
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        if (password) {
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        root.addView(input, matchWrap());
        return input;
    }

    private TextView label(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(14);
        label.setTextColor(Color.rgb(30, 41, 59));
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(12);
        label.setLayoutParams(params);
        return label;
    }

    private Button button(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(12);
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void loadSettings() {
        endpointInput.setText(preferences.getString(AppConfig.KEY_ENDPOINT,
                DEFAULT_ENDPOINT));
        apiKeyInput.setText(preferences.getString(AppConfig.KEY_API_KEY, ""));
        modelInput.setText(preferences.getString(AppConfig.KEY_MODEL, DEFAULT_MODEL));
        packageInput.setText(preferences.getString(AppConfig.KEY_PACKAGE, ""));
        intervalInput.setText(String.valueOf(preferences.getLong(AppConfig.KEY_INTERVAL, 650)));
        String savedBoardSpec = preferences.getString(
                AppConfig.KEY_BOARD_SPEC, DEFAULT_BOARD_SPEC);
        if (OLD_BOARD_SPEC.equals(savedBoardSpec)) {
            savedBoardSpec = DEFAULT_BOARD_SPEC;
            preferences.edit().putString(AppConfig.KEY_BOARD_SPEC, savedBoardSpec).apply();
        }
        boardSpecInput.setText(savedBoardSpec);
        modeSpinner.setSelection("CLAW_AUTO".equals(
                preferences.getString(AppConfig.KEY_MODE, "MATCH3")) ? 1 : 0);
    }

    private void saveSettings() {
        long interval = 650;
        try {
            interval = Math.max(350, Long.parseLong(intervalInput.getText().toString().trim()));
        } catch (NumberFormatException ignored) {
        }
        preferences.edit()
                .putString(AppConfig.KEY_ENDPOINT, endpointInput.getText().toString().trim())
                .putString(AppConfig.KEY_API_KEY, apiKeyInput.getText().toString().trim())
                .putString(AppConfig.KEY_MODEL, modelInput.getText().toString().trim())
                .putString(AppConfig.KEY_PACKAGE, packageInput.getText().toString().trim())
                .putLong(AppConfig.KEY_INTERVAL, interval)
                .putString(AppConfig.KEY_BOARD_SPEC, boardSpecInput.getText().toString().trim())
                .putString(AppConfig.KEY_MODE, modeSpinner.getSelectedItemPosition() == 1
                        ? "CLAW_AUTO" : "MATCH3")
                .apply();
    }

    private void scheduleGameControlTest(Button button, String label, String action,
                                         int x1, int y1, int x2, int y2) {
        saveSettings();
        if (!GameAccessibilityService.isConnected()) {
            Toast.makeText(this, "无障碍服务未连接，请先点击“开启无障碍服务”",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (packageInput.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "请先填写微办公的游戏包名", Toast.LENGTH_LONG).show();
            return;
        }
        button.setEnabled(false);
        saveStatus(label + "倒计时5秒：请马上切回小游戏");
        Toast.makeText(this, "请在5秒内切回小游戏，随后自动执行",
                Toast.LENGTH_LONG).show();
        statusHandler.postDelayed(() -> {
            boolean accepted = GameAccessibilityService.performTest(
                    label, action, x1, y1, x2, y2);
            button.setEnabled(true);
            if (!accepted) {
                saveStatus(label + "失败：" + GameAccessibilityService.lastFailure());
            }
        }, GAME_TEST_DELAY_MILLIS);
    }

    private void testApi(Button button) {
        saveSettings();
        String endpoint = endpointInput.getText().toString().trim();
        String apiKey = apiKeyInput.getText().toString().trim();
        String model = modelInput.getText().toString().trim();
        if (endpoint.isEmpty() || apiKey.isEmpty() || model.isEmpty()) {
            Toast.makeText(this, "请先填写 API 地址、API Key 和模型名称",
                    Toast.LENGTH_LONG).show();
            return;
        }
        button.setEnabled(false);
        saveStatus("正在测试 DeepSeek 图片识别接口…");
        apiTestExecutor.execute(() -> {
            String result;
            boolean success;
            try {
                result = runApiTest(endpoint, apiKey, model);
                success = true;
            } catch (Exception error) {
                result = readableMessage(error);
                success = false;
            }
            boolean finalSuccess = success;
            String finalResult = result;
            statusHandler.post(() -> {
                button.setEnabled(true);
                saveStatus((finalSuccess ? "API 测试成功：" : "API 测试失败：")
                        + finalResult);
                Toast.makeText(this,
                        finalSuccess ? "DeepSeek API 和图片输入正常" : "API 测试失败：" + finalResult,
                        Toast.LENGTH_LONG).show();
                refreshStatus();
            });
        });
    }

    private String runApiTest(String endpoint, String apiKey, String model) throws Exception {
        Bitmap bitmap = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(Color.rgb(32, 120, 220));
        ByteArrayOutputStream imageBytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, imageBytes);
        bitmap.recycle();
        String base64 = android.util.Base64.encodeToString(
                imageBytes.toByteArray(), android.util.Base64.NO_WRAP);

        JSONObject imageUrl = new JSONObject()
                .put("url", "data:image/jpeg;base64," + base64)
                .put("detail", "low");
        JSONArray content = new JSONArray()
                .put(new JSONObject().put("type", "text")
                        .put("text", "这是一张接口测试图片，只回复 OK"))
                .put(new JSONObject().put("type", "image_url")
                        .put("image_url", imageUrl));
        JSONObject request = new JSONObject()
                .put("model", model)
                .put("messages", new JSONArray().put(
                        new JSONObject().put("role", "user").put("content", content)))
                .put("temperature", 0)
                .put("max_tokens", 16);

        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        try {
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(45000);
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Authorization", "Bearer " + apiKey);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(request.toString().getBytes(StandardCharsets.UTF_8));
            }
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream();
            String response = readAll(stream);
            if (status < 200 || status >= 300) {
                throw new IllegalStateException("HTTP " + status + "：" + trim(response, 160));
            }
            JSONObject outer = new JSONObject(response);
            JSONArray choices = outer.optJSONArray("choices");
            if (choices == null || choices.length() == 0) {
                throw new IllegalStateException("接口已连接，但响应中没有 choices");
            }
            String reply = choices.getJSONObject(0).getJSONObject("message")
                    .optString("content", "").trim();
            return reply.isEmpty() ? "连接及图片上传正常" : trim(reply, 80);
        } finally {
            connection.disconnect();
        }
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) {
            return "";
        }
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
        }
        return result.toString();
    }

    private String readableMessage(Exception error) {
        String message = error.getMessage();
        return message == null || message.isEmpty()
                ? error.getClass().getSimpleName() : trim(message, 180);
    }

    private String trim(String value, int max) {
        return value.length() <= max ? value : value.substring(0, max) + "…";
    }

    private void saveStatus(String text) {
        preferences.edit().putString(AppConfig.KEY_STATUS, text).apply();
    }

    private void startCapture() {
        saveSettings();
        if (packageInput.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "请先填写游戏包名", Toast.LENGTH_LONG).show();
            return;
        }
        MediaProjectionManager manager =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE || resultCode != RESULT_OK || data == null) {
            return;
        }
        Intent service = new Intent(this, CaptureService.class)
                .setAction(CaptureService.ACTION_START)
                .putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_RESULT_DATA, data);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(service);
        } else {
            startService(service);
        }
        Toast.makeText(this, "已开始，请切换到目标游戏", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        statusHandler.removeCallbacksAndMessages(null);
        apiTestExecutor.shutdownNow();
        super.onDestroy();
    }
}
