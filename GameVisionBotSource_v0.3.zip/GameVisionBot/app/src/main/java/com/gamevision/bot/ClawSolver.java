package com.gamevision.bot;

import android.graphics.Bitmap;
import android.graphics.Color;

final class ClawSolver {
    static final class Detection {
        final boolean found;
        final boolean aligned;
        final int clawX;
        final int targetX;
        final int buttonX;
        final int buttonY;
        final double confidence;

        Detection(boolean found, boolean aligned, int clawX, int targetX,
                  int buttonX, int buttonY, double confidence) {
            this.found = found;
            this.aligned = aligned;
            this.clawX = clawX;
            this.targetX = targetX;
            this.buttonX = buttonX;
            this.buttonY = buttonY;
            this.confidence = confidence;
        }
    }

    private static final int PROFILE_SIZE = 1001;
    private static final int CLAW_LEFT = 180;
    private static final int CLAW_TOP = 420;
    private static final int CLAW_RIGHT = 820;
    private static final int CLAW_BOTTOM = 560;
    private static final int TARGET_LEFT = 350;
    private static final int TARGET_TOP = 570;
    private static final int TARGET_RIGHT = 650;
    private static final int TARGET_BOTTOM = 670;
    private static final int BUTTON_LEFT = 200;
    private static final int BUTTON_TOP = 730;
    private static final int BUTTON_RIGHT = 800;
    private static final int BUTTON_BOTTOM = 880;
    private static final float TAP_LEAD_MILLIS = 90f;
    private static final float ALIGN_TOLERANCE = 17f;

    private float targetX = -1;
    private float buttonX = 500;
    private float buttonY = 791;
    private float lastClawX = -1;
    private float velocity;
    private long lastFrameAt;
    private boolean sceneCalibrated;

    Detection analyze(Bitmap bitmap, long now) {
        if (!sceneCalibrated && !calibrate(bitmap)) {
            return new Detection(false, false, 0, 0,
                    Math.round(buttonX), Math.round(buttonY), 0);
        }
        Peak peak = findClaw(bitmap);
        if (peak == null || targetX < 0) {
            lastClawX = -1;
            lastFrameAt = 0;
            velocity = 0;
            return new Detection(false, false, 0, Math.round(targetX),
                    Math.round(buttonX), Math.round(buttonY), 0);
        }

        float previousX = lastClawX;
        if (previousX >= 0 && lastFrameAt > 0) {
            long elapsed = now - lastFrameAt;
            if (elapsed >= 35 && elapsed <= 500) {
                float measured = (peak.x - previousX) / elapsed;
                velocity = velocity == 0 ? measured : velocity * 0.45f + measured * 0.55f;
            }
        }

        float predictedX = peak.x + velocity * TAP_LEAD_MILLIS;
        boolean closeEnough = Math.abs(predictedX - targetX) <= ALIGN_TOLERANCE;
        boolean crossed = previousX >= 0
                && Math.abs(peak.x - targetX) <= 45
                && ((previousX < targetX && predictedX >= targetX)
                || (previousX > targetX && predictedX <= targetX));
        boolean aligned = peak.confidence >= 0.16 && (closeEnough || crossed);

        lastClawX = peak.x;
        lastFrameAt = now;
        return new Detection(true, aligned, Math.round(peak.x), Math.round(targetX),
                Math.round(buttonX), Math.round(buttonY), peak.confidence);
    }

    private boolean calibrate(Bitmap bitmap) {
        WeightedPoint button = findColoredCenter(bitmap,
                BUTTON_LEFT, BUTTON_TOP, BUTTON_RIGHT, BUTTON_BOTTOM, true);
        if (button.weight <= 5.0) {
            return false;
        }
        WeightedPoint target = findColoredCenter(bitmap,
                TARGET_LEFT, TARGET_TOP, TARGET_RIGHT, TARGET_BOTTOM, false);
        if (target.weight <= 10.0) {
            return false;
        }
        buttonX = button.x;
        buttonY = button.y;
        targetX = target.x;
        sceneCalibrated = true;
        return true;
    }

    private Peak findClaw(Bitmap bitmap) {
        float[] profile = new float[PROFILE_SIZE];
        float[] hsv = new float[3];
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int xStep = Math.max(2, width / 360);
        int yStep = Math.max(3, height / 260);
        int xStart = px(CLAW_LEFT, width);
        int xEnd = px(CLAW_RIGHT, width);
        int yStart = px(CLAW_TOP, height);
        int yEnd = px(CLAW_BOTTOM, height);
        for (int x = xStart; x < xEnd; x += xStep) {
            int normalizedX = Math.round(x * 1000f / width);
            float score = 0;
            for (int y = yStart; y < yEnd; y += yStep) {
                Color.colorToHSV(bitmap.getPixel(x, y), hsv);
                score += Math.max(0, hsv[2] - 0.65f)
                        * Math.max(0, 0.45f - hsv[1]);
            }
            profile[normalizedX] += score;
        }

        float best = 0;
        int bestX = -1;
        for (int x = CLAW_LEFT; x <= CLAW_RIGHT; x++) {
            float score = smooth(profile, x, 9);
            if (score > best) {
                best = score;
                bestX = x;
            }
        }
        if (bestX < 0 || best < 0.25f) {
            return null;
        }
        float second = 0;
        for (int x = CLAW_LEFT; x <= CLAW_RIGHT; x++) {
            if (Math.abs(x - bestX) > 55) {
                second = Math.max(second, smooth(profile, x, 9));
            }
        }
        double confidence = Math.max(0, Math.min(1, 1.0 - second / Math.max(0.001, best)));
        return new Peak(bestX, confidence);
    }

    private WeightedPoint findColoredCenter(Bitmap bitmap, int left, int top,
                                             int right, int bottom, boolean orangeOnly) {
        float[] hsv = new float[3];
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int xStep = Math.max(2, width / 420);
        int yStep = Math.max(3, height / 300);
        double weightedX = 0;
        double weightedY = 0;
        double total = 0;
        for (int x = px(left, width); x < px(right, width); x += xStep) {
            for (int y = px(top, height); y < px(bottom, height); y += yStep) {
                Color.colorToHSV(bitmap.getPixel(x, y), hsv);
                if (orangeOnly && (hsv[0] < 12 || hsv[0] > 60)) {
                    continue;
                }
                double weight = Math.max(0, hsv[1] - (orangeOnly ? 0.45 : 0.48))
                        * Math.max(0, hsv[2] - 0.55);
                if (weight == 0) {
                    continue;
                }
                weightedX += x * 1000.0 / width * weight;
                weightedY += y * 1000.0 / height * weight;
                total += weight;
            }
        }
        if (total == 0) {
            return new WeightedPoint(0, 0, 0);
        }
        return new WeightedPoint((float) (weightedX / total),
                (float) (weightedY / total), total);
    }

    private float smooth(float[] values, int center, int radius) {
        float sum = 0;
        int start = Math.max(0, center - radius);
        int end = Math.min(values.length - 1, center + radius);
        for (int index = start; index <= end; index++) {
            sum += values[index];
        }
        return sum;
    }

    private int px(int normalized, int size) {
        return Math.max(0, Math.min(size - 1, Math.round(normalized / 1000f * size)));
    }

    private static final class Peak {
        final float x;
        final double confidence;

        Peak(float x, double confidence) {
            this.x = x;
            this.confidence = confidence;
        }
    }

    private static final class WeightedPoint {
        final float x;
        final float y;
        final double weight;

        WeightedPoint(float x, float y, double weight) {
            this.x = x;
            this.y = y;
            this.weight = weight;
        }
    }
}
