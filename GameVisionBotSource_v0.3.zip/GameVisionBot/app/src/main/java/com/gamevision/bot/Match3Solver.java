package com.gamevision.bot;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.Arrays;
import java.util.Comparator;

final class Match3Solver {
    private static final int DIMENSIONS = 4;

    static final class Solution {
        final int x1;
        final int y1;
        final int x2;
        final int y2;
        final int score;
        final double confidence;
        final String signature;

        Solution(int x1, int y1, int x2, int y2, int score,
                 double confidence, String signature) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.score = score;
            this.confidence = confidence;
            this.signature = signature;
        }
    }

    private static final class BoardSpec {
        int columns = 9;
        int rows = 9;
        int left = 30;
        int top = 180;
        int right = 970;
        int bottom = 950;
        int tileTypes = 6;
    }

    static Solution solve(Bitmap bitmap, SharedPreferences preferences) {
        BoardSpec spec = parseSpec(preferences.getString(
                AppConfig.KEY_BOARD_SPEC, "9,9,30,180,970,950,6"));
        int cells = spec.rows * spec.columns;
        float[][] features = new float[cells][DIMENSIONS];
        for (int row = 0; row < spec.rows; row++) {
            for (int column = 0; column < spec.columns; column++) {
                features[row * spec.columns + column] = sampleCell(bitmap, spec, row, column);
            }
        }

        ClusterResult clustered = cluster(features, Math.min(spec.tileTypes, cells));
        if (clustered == null || clustered.confidence < 0.42) {
            return null;
        }

        int[][] board = new int[spec.rows][spec.columns];
        StringBuilder signature = new StringBuilder(cells);
        for (int row = 0; row < spec.rows; row++) {
            for (int column = 0; column < spec.columns; column++) {
                int label = clustered.labels[row * spec.columns + column];
                board[row][column] = label;
                signature.append((char) ('A' + label));
            }
        }

        int bestScore = 0;
        int bestRow = -1;
        int bestColumn = -1;
        int bestOtherRow = -1;
        int bestOtherColumn = -1;
        int[][] directions = {{0, 1}, {1, 0}};
        for (int row = 0; row < spec.rows; row++) {
            for (int column = 0; column < spec.columns; column++) {
                for (int[] direction : directions) {
                    int otherRow = row + direction[0];
                    int otherColumn = column + direction[1];
                    if (otherRow >= spec.rows || otherColumn >= spec.columns
                            || board[row][column] == board[otherRow][otherColumn]) {
                        continue;
                    }
                    swap(board, row, column, otherRow, otherColumn);
                    int score = matchScore(board, row, column)
                            + matchScore(board, otherRow, otherColumn);
                    swap(board, row, column, otherRow, otherColumn);
                    if (score > bestScore) {
                        bestScore = score;
                        bestRow = row;
                        bestColumn = column;
                        bestOtherRow = otherRow;
                        bestOtherColumn = otherColumn;
                    }
                }
            }
        }

        if (bestRow < 0) {
            return null;
        }
        return new Solution(
                centerX(spec, bestColumn),
                centerY(spec, bestRow),
                centerX(spec, bestOtherColumn),
                centerY(spec, bestOtherRow),
                bestScore,
                clustered.confidence,
                signature.toString());
    }

    private static float[] sampleCell(Bitmap bitmap, BoardSpec spec, int row, int column) {
        float centerX = (spec.left + (column + 0.5f)
                * (spec.right - spec.left) / spec.columns) / 1000f * bitmap.getWidth();
        float centerY = (spec.top + (row + 0.5f)
                * (spec.bottom - spec.top) / spec.rows) / 1000f * bitmap.getHeight();
        float cellWidth = (spec.right - spec.left) / 1000f * bitmap.getWidth() / spec.columns;
        float cellHeight = (spec.bottom - spec.top) / 1000f * bitmap.getHeight() / spec.rows;
        float[] hsv = new float[3];
        float sin = 0;
        float cos = 0;
        float saturation = 0;
        float value = 0;
        int samples = 0;
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                int x = clamp(Math.round(centerX + dx * cellWidth * 0.09f), 0, bitmap.getWidth() - 1);
                int y = clamp(Math.round(centerY + dy * cellHeight * 0.09f), 0, bitmap.getHeight() - 1);
                Color.colorToHSV(bitmap.getPixel(x, y), hsv);
                double radians = Math.toRadians(hsv[0]);
                sin += (float) Math.sin(radians) * hsv[1];
                cos += (float) Math.cos(radians) * hsv[1];
                saturation += hsv[1];
                value += hsv[2];
                samples++;
            }
        }
        return new float[]{sin / samples, cos / samples,
                saturation / samples, value / samples};
    }

    private static final class ClusterResult {
        final int[] labels;
        final double confidence;

        ClusterResult(int[] labels, double confidence) {
            this.labels = labels;
            this.confidence = confidence;
        }
    }

    private static ClusterResult cluster(float[][] points, int k) {
        if (k < 3 || points.length < k) {
            return null;
        }
        float[][] centers = new float[k][DIMENSIONS];
        centers[0] = points[0].clone();
        for (int center = 1; center < k; center++) {
            int farthest = 0;
            float farthestDistance = -1;
            for (int point = 0; point < points.length; point++) {
                float nearest = Float.MAX_VALUE;
                for (int existing = 0; existing < center; existing++) {
                    nearest = Math.min(nearest, distance(points[point], centers[existing]));
                }
                if (nearest > farthestDistance) {
                    farthestDistance = nearest;
                    farthest = point;
                }
            }
            centers[center] = points[farthest].clone();
        }

        int[] labels = new int[points.length];
        Arrays.fill(labels, -1);
        for (int iteration = 0; iteration < 12; iteration++) {
            boolean changed = false;
            float[][] sums = new float[k][DIMENSIONS];
            int[] counts = new int[k];
            for (int point = 0; point < points.length; point++) {
                int nearest = nearest(points[point], centers);
                if (labels[point] != nearest) {
                    labels[point] = nearest;
                    changed = true;
                }
                counts[nearest]++;
                for (int dimension = 0; dimension < DIMENSIONS; dimension++) {
                    sums[nearest][dimension] += points[point][dimension];
                }
            }
            for (int center = 0; center < k; center++) {
                if (counts[center] == 0) {
                    return null;
                }
                for (int dimension = 0; dimension < DIMENSIONS; dimension++) {
                    centers[center][dimension] = sums[center][dimension] / counts[center];
                }
            }
            if (!changed) {
                break;
            }
        }

        Integer[] order = new Integer[k];
        for (int i = 0; i < k; i++) {
            order[i] = i;
        }
        Arrays.sort(order, Comparator.comparingDouble(i -> canonicalKey(centers[i])));
        int[] canonical = new int[k];
        for (int rank = 0; rank < k; rank++) {
            canonical[order[rank]] = rank;
        }
        for (int i = 0; i < labels.length; i++) {
            labels[i] = canonical[labels[i]];
        }

        double ratioSum = 0;
        for (float[] point : points) {
            float best = Float.MAX_VALUE;
            float second = Float.MAX_VALUE;
            for (float[] center : centers) {
                float candidate = distance(point, center);
                if (candidate < best) {
                    second = best;
                    best = candidate;
                } else if (candidate < second) {
                    second = candidate;
                }
            }
            ratioSum += Math.min(3.0, second / Math.max(0.0001, best)) / 3.0;
        }
        return new ClusterResult(labels, ratioSum / points.length);
    }

    private static int nearest(float[] point, float[][] centers) {
        int result = 0;
        float best = Float.MAX_VALUE;
        for (int center = 0; center < centers.length; center++) {
            float candidate = distance(point, centers[center]);
            if (candidate < best) {
                best = candidate;
                result = center;
            }
        }
        return result;
    }

    private static float distance(float[] first, float[] second) {
        float sum = 0;
        for (int i = 0; i < DIMENSIONS; i++) {
            float delta = first[i] - second[i];
            sum += delta * delta;
        }
        return sum;
    }

    private static double canonicalKey(float[] center) {
        double hue = Math.atan2(center[0], center[1]);
        if (hue < 0) {
            hue += Math.PI * 2;
        }
        return hue * 10 + center[3];
    }

    private static int matchScore(int[][] board, int row, int column) {
        int value = board[row][column];
        int horizontal = 1 + count(board, row, column, 0, -1, value)
                + count(board, row, column, 0, 1, value);
        int vertical = 1 + count(board, row, column, -1, 0, value)
                + count(board, row, column, 1, 0, value);
        int score = 0;
        if (horizontal >= 3) {
            score += horizontal * horizontal;
        }
        if (vertical >= 3) {
            score += vertical * vertical;
        }
        return score;
    }

    private static int count(int[][] board, int row, int column,
                             int rowStep, int columnStep, int value) {
        int result = 0;
        int nextRow = row + rowStep;
        int nextColumn = column + columnStep;
        while (nextRow >= 0 && nextRow < board.length
                && nextColumn >= 0 && nextColumn < board[0].length
                && board[nextRow][nextColumn] == value) {
            result++;
            nextRow += rowStep;
            nextColumn += columnStep;
        }
        return result;
    }

    private static void swap(int[][] board, int firstRow, int firstColumn,
                             int secondRow, int secondColumn) {
        int value = board[firstRow][firstColumn];
        board[firstRow][firstColumn] = board[secondRow][secondColumn];
        board[secondRow][secondColumn] = value;
    }

    private static int centerX(BoardSpec spec, int column) {
        return Math.round(spec.left + (column + 0.5f)
                * (spec.right - spec.left) / spec.columns);
    }

    private static int centerY(BoardSpec spec, int row) {
        return Math.round(spec.top + (row + 0.5f)
                * (spec.bottom - spec.top) / spec.rows);
    }

    private static BoardSpec parseSpec(String value) {
        BoardSpec spec = new BoardSpec();
        try {
            String[] parts = value.split(",");
            if (parts.length == 7) {
                int columns = Integer.parseInt(parts[0].trim());
                int rows = Integer.parseInt(parts[1].trim());
                int left = Integer.parseInt(parts[2].trim());
                int top = Integer.parseInt(parts[3].trim());
                int right = Integer.parseInt(parts[4].trim());
                int bottom = Integer.parseInt(parts[5].trim());
                int types = Integer.parseInt(parts[6].trim());
                if (columns >= 3 && columns <= 12 && rows >= 3 && rows <= 12
                        && left >= 0 && top >= 0 && right <= 1000 && bottom <= 1000
                        && right > left && bottom > top && types >= 3 && types <= 10) {
                    spec.columns = columns;
                    spec.rows = rows;
                    spec.left = left;
                    spec.top = top;
                    spec.right = right;
                    spec.bottom = bottom;
                    spec.tileTypes = types;
                }
            }
        } catch (RuntimeException ignored) {
        }
        return spec;
    }

    private static int clamp(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private Match3Solver() {
    }
}
