package com.gamevision.bot;

final class AppConfig {
    static final String PREFS = "game_vision_settings";
    static final String KEY_ENDPOINT = "endpoint";
    static final String KEY_API_KEY = "api_key";
    static final String KEY_MODEL = "model";
    static final String KEY_PACKAGE = "target_package";
    static final String KEY_INTERVAL = "interval_ms";
    static final String KEY_MODE = "mode";
    static final String KEY_BOARD_SPEC = "board_spec";
    static final String KEY_STATUS = "last_status";

    private AppConfig() {
    }
}
