package com.gamevision.bot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class GameAccessibilityService extends AccessibilityService {
    private static volatile GameAccessibilityService instance;
    private volatile String foregroundPackage = "";

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event != null && event.getPackageName() != null) {
            foregroundPackage = event.getPackageName().toString();
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        if (instance == this) {
            instance = null;
        }
        super.onDestroy();
    }

    static boolean perform(String action, int x1, int y1, int x2, int y2) {
        GameAccessibilityService service = instance;
        if (service == null) {
            return false;
        }
        SharedPreferences prefs = service.getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE);
        String allowedPackage = prefs.getString(AppConfig.KEY_PACKAGE, "").trim();
        if (allowedPackage.isEmpty() || !allowedPackage.equals(service.foregroundPackage)) {
            return false;
        }
        if ("wait".equalsIgnoreCase(action)) {
            return true;
        }
        if (!inside(x1) || !inside(y1) || !inside(x2) || !inside(y2)) {
            return false;
        }

        int width = service.getResources().getDisplayMetrics().widthPixels;
        int height = service.getResources().getDisplayMetrics().heightPixels;
        float startX = x1 / 1000f * width;
        float startY = y1 / 1000f * height;
        Path path = new Path();
        path.moveTo(startX, startY);

        long duration;
        if ("tap".equalsIgnoreCase(action)) {
            duration = 80;
        } else if ("swipe".equalsIgnoreCase(action)) {
            path.lineTo(x2 / 1000f * width, y2 / 1000f * height);
            duration = 280;
        } else {
            return false;
        }

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, duration))
                .build();
        return service.dispatchGesture(gesture, null, null);
    }

    private static boolean inside(int value) {
        return value >= 0 && value <= 1000;
    }
}
