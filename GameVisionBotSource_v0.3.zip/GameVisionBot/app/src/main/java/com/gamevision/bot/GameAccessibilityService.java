package com.gamevision.bot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class GameAccessibilityService extends AccessibilityService {
    private static volatile GameAccessibilityService instance;
    private volatile String foregroundPackage = "";
    private static volatile String lastFailure = "";

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event != null && event.getPackageName() != null) {
            foregroundPackage = event.getPackageName().toString();
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        if (instance == this) {
            instance = null;
        }
        super.onDestroy();
    }

    static boolean perform(String action, int x1, int y1, int x2, int y2) {
        return performInternal(null, action, x1, y1, x2, y2);
    }

    static boolean performTest(String label, String action,
                               int x1, int y1, int x2, int y2) {
        return performInternal(label, action, x1, y1, x2, y2);
    }

    private static boolean performInternal(String testLabel, String action,
                                           int x1, int y1, int x2, int y2) {
        GameAccessibilityService service = instance;
        if (service == null) {
            lastFailure = "无障碍服务未连接";
            return false;
        }
        SharedPreferences prefs = service.getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE);
        String allowedPackage = prefs.getString(AppConfig.KEY_PACKAGE, "").trim();
        String activePackage = service.activePackage();
        if (allowedPackage.isEmpty()) {
            lastFailure = "目标应用包名为空";
            return false;
        }
        if (!packageMatches(allowedPackage, activePackage)) {
            lastFailure = "包名不匹配：当前 " + display(activePackage)
                    + "，已填 " + allowedPackage;
            return false;
        }
        if ("wait".equalsIgnoreCase(action)) {
            lastFailure = "";
            return true;
        }
        if (!inside(x1) || !inside(y1) || !inside(x2) || !inside(y2)) {
            lastFailure = "模型返回的坐标超出范围";
            return false;
        }

        int width = service.getResources().getDisplayMetrics().widthPixels;
        int height = service.getResources().getDisplayMetrics().heightPixels;
        float startX = x1 / 1000f * width;
        float startY = y1 / 1000f * height;
        Path path = new Path();
        path.moveTo(startX, startY);

        long duration;
        if ("tap".equalsIgnoreCase(action)) {
            duration = 80;
        } else if ("swipe".equalsIgnoreCase(action)) {
            path.lineTo(x2 / 1000f * width, y2 / 1000f * height);
            duration = 280;
        } else {
            lastFailure = "不支持的动作：" + action;
            return false;
        }

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, duration))
                .build();
        GestureResultCallback callback = testLabel == null ? null
                : new GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription gestureDescription) {
                        lastFailure = "";
                        service.saveStatus(testLabel + "成功：系统已完成手势");
                    }

                    @Override
                    public void onCancelled(GestureDescription gestureDescription) {
                        lastFailure = "系统取消了测试手势";
                        service.saveStatus(testLabel + "失败：" + lastFailure);
                    }
                };
        boolean accepted = service.dispatchGesture(gesture, callback, null);
        lastFailure = accepted ? "" : "系统拒绝了无障碍手势";
        if (testLabel != null) {
            service.saveStatus(accepted
                    ? testLabel + "已发送，等待系统完成…"
                    : testLabel + "失败：" + lastFailure);
        }
        return accepted;
    }

    static boolean isConnected() {
        return instance != null;
    }

    static String currentPackage() {
        GameAccessibilityService service = instance;
        return service == null ? "" : service.activePackage();
    }

    static String lastFailure() {
        return lastFailure;
    }

    static boolean performSelfTest() {
        GameAccessibilityService service = instance;
        if (service == null) {
            lastFailure = "无障碍服务未连接，请先开启";
            return false;
        }
        String activePackage = service.activePackage();
        if (!service.getPackageName().equals(activePackage)) {
            lastFailure = "请停留在 GameVisionBot 页面再测试；当前为 "
                    + display(activePackage);
            return false;
        }

        int width = service.getResources().getDisplayMetrics().widthPixels;
        int height = service.getResources().getDisplayMetrics().heightPixels;
        Path path = new Path();
        path.moveTo(width * 0.5f, height * 0.72f);
        path.lineTo(width * 0.5f, height * 0.38f);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 550))
                .build();
        boolean accepted = service.dispatchGesture(gesture,
                new GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription gestureDescription) {
                        lastFailure = "";
                        service.saveStatus("手机操控测试成功：无障碍滑动已完成");
                    }

                    @Override
                    public void onCancelled(GestureDescription gestureDescription) {
                        lastFailure = "系统取消了测试手势";
                        service.saveStatus("手机操控测试失败：" + lastFailure);
                    }
                }, null);
        if (accepted) {
            service.saveStatus("手机操控测试已发送，等待系统完成…");
            lastFailure = "";
        } else {
            lastFailure = "系统拒绝了测试手势";
            service.saveStatus("手机操控测试失败：" + lastFailure);
        }
        return accepted;
    }

    private String activePackage() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            try {
                CharSequence packageName = root.getPackageName();
                if (packageName != null && packageName.length() > 0) {
                    return packageName.toString();
                }
            } finally {
                root.recycle();
            }
        }
        return foregroundPackage;
    }

    private static boolean packageMatches(String allowedPackage, String activePackage) {
        return allowedPackage.equals(activePackage)
                || activePackage.startsWith(allowedPackage + ":");
    }

    private static String display(String value) {
        return value == null || value.isEmpty() ? "未知" : value;
    }

    private void saveStatus(String text) {
        getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE)
                .edit().putString(AppConfig.KEY_STATUS, text).apply();
    }

    private static boolean inside(int value) {
        return value >= 0 && value <= 1000;
    }
}
